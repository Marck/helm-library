{{- /*
servarr.values — the effective values for one Servarr app.

Everything an app repeats is derived here from `app.name`, `app.uid` and
`app.port`: resource names, the NFS directory, the hostname and TLS secret, the
PUID/PGID env, the probe ports, the gatus endpoint. An app chart that wants
something else simply sets it — its own values are merged LAST and win, which is
how radarr keeps its node-local /config and its extra init container.
*/ -}}
{{- /* The ingress deliberately passes NO tlsSecretName. This cluster serves one
       wildcard certificate through Traefik's default TLSStore, so the old
       "<name>-tls" named a Secret nobody creates and Traefik logged
       "Error configuring TLS: secret <ns>/<name>-tls does not exist" for every
       Servarr ingress on every config reload. common 0.14.0 makes secretName
       opt-in, and an app that genuinely owns a certificate can still pass
       ingress.tlsSecretName through its own values. */ -}}
{{- /* An NAS path from values: absolute is used as is, relative hangs off
       global.cluster.nas.root. Required only when a relative path needs it. */ -}}
{{- define "servarr.nasPath" -}}
{{- if hasPrefix "/" .path -}}
{{- .path -}}
{{- else -}}
{{- printf "%s/%s" (.root | required "servarr: global.cluster.nas.root is required for a relative NAS path (set it in the consuming repo's cluster values, or give an absolute app.*Path)" | trimSuffix "/") .path -}}
{{- end -}}
{{- end -}}

{{- define "servarr.values" -}}
{{- $v := .Values -}}
{{- $app := $v.app | default dict -}}
{{- $name := $app.name | required "servarr: app.name is required (it names every resource, the NFS directory and the hostname)" -}}
{{- $uid := $app.uid | required "servarr: app.uid is required — unique per app, so a squashed NFS write cannot land as another app's user" | int -}}
{{- $port := $app.port | required "servarr: app.port is required" | int -}}
{{- /* Site facts: global.cluster from the consuming repo, never a default here.
       A subchart sees only its own block plus `global`, hence global.cluster
       rather than the parent's .Values.cluster. */ -}}
{{- $cluster := (($v.global).cluster) | default dict -}}
{{- $nas := $cluster.nas | default dict -}}
{{- $domain := $app.domain | default $cluster.domain | required "servarr: global.cluster.domain is required (the hostname is <app.name>.<domain>); set it in the consuming repo's cluster values" -}}
{{- $nfsServer := $app.nfsServer | default $nas.server | required "servarr: global.cluster.nas.server is required (the NFS server behind every volume); set it in the consuming repo's cluster values" -}}
{{- $gid := $app.gid | default 100 | int -}}
{{- $title := $app.title | default ($name | title) -}}
{{- $probe := dict "path" "/" "port" $port -}}
{{- $volumeMounts := list (dict "name" "config" "mountPath" ($v.config).mountPath) -}}
{{- $volumes := list (dict "name" "config" "persistentVolumeClaim" (dict "claimName" (printf "%s-config-pvc" $name))) -}}
{{- $pvs := dict "config" (dict
      "enabled" true
      "name" (printf "%s-config-pv" $name)
      "pvcName" (printf "%s-config-pvc" $name)
      "storageClassName" (printf "%s-config" $name)
      "size" ($v.config).size
      "accessModes" (list "ReadWriteOnce")
      "mountOptions" ($v.config).mountOptions
      "nfs" (dict "server" $nfsServer "path" (printf "%s/%s" (include "servarr.nasPath" (dict "root" $nas.root "path" $app.configPath)) $name))) -}}
{{- /* The media tree is ReadWriteMany: shared with the download client and the
       other Servarr apps, so several writers hold it at once. */ -}}
{{- if ($v.media).enabled -}}
{{- $volumeMounts = append $volumeMounts (dict "name" "media" "mountPath" $v.media.mountPath) -}}
{{- $volumes = append $volumes (dict "name" "media" "persistentVolumeClaim" (dict "claimName" (printf "%s-media-pvc" $name))) -}}
{{- $_ := set $pvs "media" (dict
      "enabled" true
      "name" (printf "%s-media-pv" $name)
      "pvcName" (printf "%s-media-pvc" $name)
      "storageClassName" (printf "%s-media" $name)
      "size" $v.media.size
      "accessModes" (list "ReadWriteMany")
      "nfs" (dict "server" $nfsServer "path" (include "servarr.nasPath" (dict "root" $nas.root "path" $app.mediaPath)))) -}}
{{- end -}}
{{- /* The completed-downloads tree, for the apps that import from it. Also
       ReadWriteMany: the download client writes here while the importer reads
       and then deletes.

       The mount is scoped with subPath to <tree>/<app.name>, so the pod sees
       ONLY its own directory and the in-container path is identical to the
       Directory configured in the app's download client. That equality is the
       whole feature: the app resolves the absolute path the client reports
       rather than translating it, so with the wrong path (or no mount) sonarr
       logs, for every grab,

         Remote download client Transmission places downloads in
         /downloads/automated/sonarr but this directory does not appear to exist.

       and the item sits at completed / importPending forever. */ -}}
{{- if ($v.downloads).enabled -}}
{{- $dlSubPath := join "/" (compact (list (($v.downloads.tree | default "") | trimAll "/") $name)) -}}
{{- $dlMountPath := printf "%s/%s" ($v.downloads.root | trimSuffix "/") $dlSubPath -}}
{{- $volumeMounts = append $volumeMounts (dict "name" "downloads" "mountPath" $dlMountPath "subPath" $dlSubPath "readOnly" false) -}}
{{- $volumes = append $volumes (dict "name" "downloads" "persistentVolumeClaim" (dict "claimName" (printf "%s-downloads-pvc" $name))) -}}
{{- $_ := set $pvs "downloads" (dict
      "enabled" true
      "name" (printf "%s-downloads-pv" $name)
      "pvcName" (printf "%s-downloads-pvc" $name)
      "storageClassName" (printf "%s-downloads" $name)
      "size" $v.downloads.size
      "accessModes" (list "ReadWriteMany")
      "nfs" (dict "server" $nfsServer "path" (include "servarr.nasPath" (dict "root" $nas.root "path" ($app.downloadsPath | required "servarr: app.downloadsPath is required when downloads.enabled"))))) -}}
{{- end -}}
{{- $host := printf "%s.%s" $name $domain -}}
{{- /* supplementalGroups: the shared NAS group only matters to the apps that
       mount a shared NFS tree. Prowlarr talks to indexers and never touches
       one, so it does not carry the group. The downloads tree needs it for the
       same reason media does: its files are group-owned by the NAS group, and
       an importer that cannot read them cannot import. */ -}}
{{- $derived := dict
    "fullnameOverride" $name
    "podSecurityContext" (merge
       (dict
         "fsGroup" $uid
         "fsGroupChangePolicy" "OnRootMismatch"
         "seccompProfile" (dict "type" "RuntimeDefault"))
       (ternary (dict "supplementalGroups" (list $gid)) dict (or (($v.media).enabled | default false) (($v.downloads).enabled | default false))))
    "env" (dict "PUID" (printf "%d" $uid) "PGID" (printf "%d" $gid) "TZ" ($cluster.timezone | default "Etc/UTC"))
    "service" (dict "type" "ClusterIP" "port" $port "portName" "http" "targetPort" "http")
    "ingress" (dict
       "annotations" (dict "gatus.home-operations.com/endpoint" (printf "name: %s\ngroup: %s\nclient: { timeout: 30s }\nconditions: [\"[STATUS] < 500\"]\nalerts: [{ type: pushover }]\n" $title $app.gatusGroup))
       "hosts" (list (dict "host" $host "paths" (list (dict "path" "/" "pathType" "Prefix"))))
       "serviceName" (printf "%s-app" $name)
       "servicePort" $port)
    "probes" (dict
       "liveness" (dict "httpGet" $probe)
       "readiness" (dict "httpGet" $probe))
    "persistenceVolumes" $pvs
    "volumeMounts" $volumeMounts
    "volumes" $volumes
    "externalAuth" (dict
       "uid" $uid
       "gid" $gid
       "volumeMounts" (list (dict "name" "config" "mountPath" ($v.config).mountPath))) -}}
{{- /* The app's own values win: derived defaults first, then everything the
       chart and the app set on top. */ -}}
{{- $resolved := mergeOverwrite $derived (omit (deepCopy $v) "app" "config" "media" "downloads") -}}
{{- /* The External-auth edit is an init container like any other, appended LAST
       so it has the final word on the auth mode: it patches config.xml, and a
       restore step running after it would put the old setting back. Rendered
       here rather than by the library -- common knows how to run an init
       container, not what a Servarr auth policy is. */ -}}
{{- $auth := $resolved.externalAuth | default dict -}}
{{- if $auth.enabled -}}
{{- $inits := concat ($resolved.initContainers | default list) (include "servarr.externalAuth" (dict "Config" $resolved "Auth" $auth) | fromYamlArray) -}}
{{- $_ := set $resolved "initContainers" $inits -}}
{{- end -}}
{{- toYaml $resolved -}}
{{- end -}}

{{- /* A Root context whose .Values are the resolved ones above, so the common
       helpers see exactly what a hand-written chart would have passed. */ -}}
{{- define "servarr.context" -}}
{{- $ctx := deepCopy . -}}
{{- $_ := set $ctx "Values" (include "servarr.values" . | fromYaml) -}}
{{- $ctx | toYaml -}}
{{- end -}}
